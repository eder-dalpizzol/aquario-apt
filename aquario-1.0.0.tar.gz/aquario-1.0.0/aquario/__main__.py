from .game import main
main()
